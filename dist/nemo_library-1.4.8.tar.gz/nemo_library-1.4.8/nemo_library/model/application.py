from dataclasses import dataclass, asdict, field

from nemo_library.utils.utils import get_internal_name


@dataclass
class Forecast:
    """
    Represents a forecast configuration.

    Attributes:
        groupBy (str): The attribute to group by.
        metric (str): The metric to forecast.
    """

    groupBy: str
    metric: str


@dataclass
class PageReference:
    """
    Represents a reference to a page.

    Attributes:
        order (int): The order of the page.
        page (str): The page identifier.
    """

    order: int
    page: str


@dataclass
class Application:
    """
    Represents an application configuration.

    Attributes:
        active (bool): Indicates if the application is active.
        description (str): The description of the application.
        descriptionTranslations (dict[str, str]): Translations for the description.
        displayName (str): The display name of the application.
        displayNameTranslations (dict[str, str]): Translations for the display name.
        download (str): The download link for the application.
        forecasts (list[Forecast]): List of forecast configurations.
        formatCompact (bool): Indicates if the format is compact.
        internalName (str): The internal name of the application.
        links (list[str]): List of related links.
        models (list[str]): List of associated models.
        pages (list[PageReference]): List of page references.
        scopeName (str): The scope name of the application.
        id (str): The unique identifier of the application.
        projectId (str): The project identifier.
        tenant (str): The tenant identifier.
    """

    active: bool = True
    description: str = ""
    descriptionTranslations: dict[str, str] = field(default_factory=dict)
    displayName: str = None
    displayNameTranslations: dict[str, str] = field(default_factory=dict)
    download: str = ""
    forecasts: list[Forecast] = field(default_factory=list)
    formatCompact: bool = False
    internalName: str = None
    links: list[str] = field(default_factory=list)
    models: list[str] = field(default_factory=list)
    pages: list[PageReference] = field(default_factory=list)
    scopeName: str = ""
    id: str = ""
    projectId: str = ""
    tenant: str = ""

    def to_dict(self):
        """
        Converts the Application instance to a dictionary.

        Returns:
            dict: The dictionary representation of the Application instance.
        """
        return asdict(self)

    def __post_init__(self):
        """
        Post-initialization processing to set the internal name if not provided.
        """
        if self.internalName is None:
            self.internalName = get_internal_name(self.displayName)
